// unique_lock::lock/unlock
#include <iostream>       // std::cout
#include <thread>         // std::thread
#include <mutex>          // std::mutex, std::unique_lock, std::defer_lock

#define LOOPS 10000
void f1();
void f2();
std::mutex mtx;           // mutex for critical section
int value=0;

int main ()
{
  std::thread t1(f1);
  std::thread t2(f2);
  
  t1.join();
  t2.join();

  std::cout<<"valor de las sección critica:"<<value<<std::endl;
  
  return 0;
}

void f1(){
  //std::unique_lock<std::mutex> lck (mtx,std::defer_lock);
  for (int i = 0; i < LOOPS; i++){
    //lck.lock();
    value+=1;  
    //lck.unlock(); 
    std::cout<<"f1:"<<value<<std::endl;
  }
}

void f2(){
  //std::unique_lock<std::mutex> lck (mtx,std::defer_lock);
  for (int i = 0; i < LOOPS; i++){
    //lck.lock();
    value-=1;  
    //lck.unlock(); 
    std::cout<<"f2:"<<value<<std::endl;
  }
}
