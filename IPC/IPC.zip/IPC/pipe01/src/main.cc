#include <unistd.h>
#include <iostream>
#include <string>
#include<sys/wait.h>
using namespace std;

int main (int argc,char** argv) {

    int arr[] = {1,2,3,4,5,6,7,8,9,10};
    int arrSize = sizeof(arr)/sizeof(int);
    int ini, end;
    int fd[2];  // file descriptor for the pipe
    int pid;  // process ID


    // create the pipe
    if (pipe(fd) == -1) {
        std::cerr<< "Error: pipe creation failed" << std::endl;
        return 1;  
    }
    
    pid = fork();  // create a new process
    if (pid< 0) {  // fork failed
        
        std::cerr<< "Error: fork failed" << std::endl;
        return 1;
    
    } else if (pid == 0) {   //child process
        
        ini = 0;
        end = ini + arrSize/2;

    } else {   
        
        ini = arrSize/2;
        end = arrSize;

    }

    int sum = 0;
    for(int i = ini; i<end; i++){
        sum += arr[i];
    }
     
    std::cout <<"suma parcial : "<<sum<<std::endl;

    if (pid == 0) {   //child process
        close(fd[0]);
        write(fd[1],&sum,sizeof(sum));
        close(fd[1]);

    } else {   //parent process 
        int sumFromChild;
        close(fd[1]);
        read(fd[0],&sumFromChild,sizeof(sumFromChild));
        close(fd[0]);
        //este proceso realiza el totalizado
        int totalSum = sum + sumFromChild;    
        std::cout <<"suma total : "<< totalSum <<std::endl;
         wait(NULL);
    }

    return 0;
}