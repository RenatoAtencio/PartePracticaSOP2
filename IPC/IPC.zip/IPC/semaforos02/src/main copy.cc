#include <unistd.h>
#include <stdio.h>
#include <pthread.h>

#define LOOPS 10000
static void *f1(void *arg);
static void *f2(void *arg);

static int value = 0;

int main (void) {

    pthread_t th1,th2;
    pthread_create(&th1,NULL, *f1, NULL);
    pthread_create(&th2,NULL, *f2, NULL);

    pthread_join(th1,NULL); 
    pthread_join(th2,NULL);

    printf("valor de las sección critica: %d ",value);
    
    return 0;
}

 static void *f1(void *arg){
  for (int i = 0; i < LOOPS; i++){
    value+=1;   
  }
}

static void *f2(void *arg){
  for (int i = 0; i < LOOPS; i++){
    value-=1;   
  }
}
