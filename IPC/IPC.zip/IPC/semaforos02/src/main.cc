#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <semaphore.h>

#define LOOPS 10000
void *f1(void *arg);
void *f2(void *arg);

static int value = 0;
//variable tipo semaforo
//sem_t sem1;

int main (void) {

    pthread_t th1,th2;

    //inicializa
    //sem_init(&sem1, 0, 1);

    pthread_create(&th1,NULL, &f1, NULL);
    pthread_create(&th2,NULL, &f2, NULL);
   
    pthread_join(th1,NULL); 
    pthread_join(th2,NULL); 
   
    std::cout << "Valor final : " << value << std::endl;
    
    return 0;
}

 void *f1(void *arg){
  for (int i = 0; i < LOOPS; i++){
    //sem_wait(&sem1);
    value+=1;  
    //sem_post(&sem1);
    std::cout << "f1 : " << value << std::endl; 
  }
  return NULL;
}

void *f2(void *arg){
  for (int i = 0; i < LOOPS; i++){
    //sem_wait(&sem1);
    value-=1;   
    //sem_post(&sem1);
    std::cout << "f2 : " << value << std::endl;
  }
  return NULL;
}
