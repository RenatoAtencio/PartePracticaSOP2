#include <unistd.h>
#include <iostream>
#include <string>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include<sys/wait.h>

using namespace std;
#define FIFO_PATH "../myfifo" // Path to the named pipe

int main (int argc,char** argv) {

    if(mkfifo (FIFO_PATH,0666)==-1){
        if(errno!=EEXIST){
            std::cout<<"no pudo crear el archivo fifo"<<std::endl;
            return 1;
        }
    }

   int fd;
   int data;

   fd = open(FIFO_PATH, O_RDONLY);
   if (fd == -1) {
      perror("open");
      exit(EXIT_FAILURE);
   }

   read(fd, &data, sizeof(data));
   std::cout<<"mensaje recibido: "<< data <<std::endl;

    // Close the named pipe
    close(fd);
    
    std::cout<<"---------------------"<<std::endl;
    std::cout<<"Abriendo canal..."<<std::endl;
    fd = open(FIFO_PATH,O_WRONLY);
    std::cout<<"Abierto"<<std::endl;
    char message[] = "Hello, named pipe!";
    if(write(fd, message, sizeof(message))==-1){
        return 2;
    }

    std::cout<<"enviando el mensaje : "<<message<<std::endl;
    close(fd);
    std::cout<<"cerrado..."<<std::endl;

    return 0;
}