#include <unistd.h>
#include <iostream>
#include <string>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>

using namespace std;
#define FIFO_PATH "../myfifo" // Path to the named pipe

int main (int argc,char** argv) {

    if(mkfifo (FIFO_PATH,0666)==-1){
        if(errno!=EEXIST){
            std::cout<<"no pudo crear el archivo fifo"<<std::endl;
            return 1;
        }
    }

    std::cout<<"Abriendo canal..."<<std::endl;
    int fd = open(FIFO_PATH,O_WRONLY);
    std::cout<<"Abierto"<<std::endl;
    int x = 21;
    
    if(write(fd, &x, sizeof(x))==-1){
        return 2;
    }
    std::cout<<"enviando el mensaje : "<<x<<std::endl;
    close(fd);
    std::cout<<"cerrado..."<<std::endl;

   std::cout<<"---------------------"<<std::endl;
    fd = open(FIFO_PATH, O_RDONLY);
   if (fd == -1) {
      perror("open");
      exit(EXIT_FAILURE);
   }

   char buffer[100];
   read(fd, buffer, sizeof(buffer));
   std::cout<<"mensaje recibido: "<< buffer <<std::endl;

   // Close the named pipe
   close(fd);

    return 0;
}