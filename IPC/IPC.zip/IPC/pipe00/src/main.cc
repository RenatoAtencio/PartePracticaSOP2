#include <unistd.h>
#include <iostream>
#include <string>
using namespace std;

int main (int argc,char** argv) {

    int fd[2];  // file descriptor for the pipe
    int pid;  // process ID


    // create the pipe
    if (pipe(fd) == -1) {
        std::cerr<< "Error: pipe creation failed" << std::endl;
        return 1;  
    }
    
    pid = fork();  // create a new process
    if (pid< 0) {  // fork failed
        std::cerr<< "Error: fork failed" << std::endl;
        return 1;
    } else if (pid > 0) {  // parent process
        close(fd[0]);  // close the read end of the pipe
        char message[256] = "Hello from the parent process";
        // write the message to the pipe
        if (write(fd[1], message, sizeof(message)) == -1) {
            std::cerr<< "Error: write to pipe failed" << std::endl;
            return 1;  
        }
        close(fd[1]);  // close the write end of the pipe
    } else {  // child process
        
        close(fd[1]);  // close the write end of the pipe
        char buffer[256];
        // read the message from the pipe
        if (read(fd[0], buffer, sizeof(buffer)) == -1) {
            std::cerr<< "Error: read from pipe failed" << std::endl;
            return 1;   
        }
        std::cout<< "Received message: " << buffer << std::endl;
        close(fd[0]);  // close the read end of the pipe
    }
     
    return 0;
}