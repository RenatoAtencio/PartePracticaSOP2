#include <iostream>

int main() {
    int num;
    while (std::cin >> num) {
        std::cout << num + 2 << std::endl;
    }

    return 0;
}

