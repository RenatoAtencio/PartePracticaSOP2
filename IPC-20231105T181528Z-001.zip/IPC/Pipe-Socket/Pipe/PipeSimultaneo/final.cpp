#include <iostream>

int main() {
    int num;
    while (std::cin >> num) {
        std::cout << "Número procesado: " << num << std::endl;
    }

    return 0;
}
